package com.simsim.capitalsim.game.utils

const val WIDTH_UI  = 1005f
const val HEIGHT_UI = 2176f

const val TIME_ANIM_SCREEN = 0.34f