package com.uxo.monaxa.game.actors.checkbox

import com.tinkf.tnkonveer.game.actors.checkbox.ACheckBox

class ACheckBoxGroup {
    var currentCheckedCheckBox: ACheckBox? = null
}