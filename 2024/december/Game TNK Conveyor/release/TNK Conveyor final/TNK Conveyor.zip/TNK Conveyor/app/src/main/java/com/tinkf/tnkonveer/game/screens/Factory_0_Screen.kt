package com.tinkf.tnkonveer.game.screens

import com.badlogic.gdx.graphics.Color
import com.badlogic.gdx.scenes.scene2d.ui.Image
import com.badlogic.gdx.scenes.scene2d.ui.Label
import com.badlogic.gdx.scenes.scene2d.ui.Label.LabelStyle
import com.badlogic.gdx.utils.Align
import com.tinkf.tnkonveer.game.LibGDXGame
import com.tinkf.tnkonveer.game.actors.AButton
import com.tinkf.tnkonveer.game.actors.AFactoryProgress
import com.tinkf.tnkonveer.game.actors.AOrder
import com.tinkf.tnkonveer.game.utils.TIME_ANIM
import com.tinkf.tnkonveer.game.utils.actor.animHide
import com.tinkf.tnkonveer.game.utils.actor.animShow
import com.tinkf.tnkonveer.game.utils.advanced.AdvancedScreen
import com.tinkf.tnkonveer.game.utils.advanced.AdvancedStage
import com.tinkf.tnkonveer.game.utils.font.FontParameter
import com.tinkf.tnkonveer.game.utils.region
import com.tinkf.tnkonveer.game.utils.runGDX
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class Factory_0_Screen(override val game: LibGDXGame) : AdvancedScreen() {

    companion object {
        var INTERIOR_INDEX = 0
            private set
        var BODY_INDEX = 0
            private set
    }

    private var TAP_COUNT  = 1
    private val percentTap = 100f / TAP_COUNT

    private val fontParameter = FontParameter().setCharacters(FontParameter.CharType.ALL).setSize(42)
    private val font          = fontGenerator_Pusia.generateFont(fontParameter)
    private val ls            = LabelStyle(font, Color.WHITE)

    private val lblTap = Label("Нажмите $TAP_COUNT раз", ls)

    private val aProgress  = AFactoryProgress(this)
    private val aOrder     = AOrder(this, INTERIOR_INDEX, BODY_INDEX)
    private val imgFactory = Image(game.all.t0)
    private val btnCreate  = AButton(this, AButton.Type.Create)

    override fun show() {
        INTERIOR_INDEX = (0..2).random()
        BODY_INDEX     = (0..2).random()

        aOrder.update(INTERIOR_INDEX, BODY_INDEX)

        stageUI.root.animHide()
        setBackBackground(game.loader.background_1.region)
        super.show()
        stageUI.root.animShow(TIME_ANIM)
    }

    override fun AdvancedStage.addActorsOnStageUI() {
        addActors(aProgress, aOrder, imgFactory, btnCreate, lblTap)
        aProgress.setBounds(158f,1728f,560f,125f)
        aOrder.setBounds(147f,1158f,583f,450f)
        imgFactory.setBounds(29f,515f,819f,433f)
        btnCreate.setBounds(157f,148f,563f,128f)

        btnCreate.setOnClickListener(null) {
            game.soundUtil.apply { play(game.soundUtil.listS.random()) }

            btnCreate.disable()
            aProgress.progressPercentFlow.value += percentTap
            TAP_COUNT--
            lblTap.setText("Нажмите $TAP_COUNT раз")

            coroutine?.launch {
                delay(400)
                runGDX {
                    if (TAP_COUNT <= 0) {
                        game.soundUtil.apply { play(success, 0.2f) }

                        root.animHide(TIME_ANIM) {
                            game.navigationManager.navigate(Factory_1_Screen::class.java.name)
                        }
                    } else btnCreate.enable()
                }
            }
        }

        lblTap.apply {
            setBounds(320f, 58f, 236f, 29f)
            setAlignment(Align.center)
        }

    }

}