package com.liberator.wisoliter.game.utils.actor

import com.badlogic.gdx.math.Interpolation
import com.badlogic.gdx.math.Polygon
import com.badlogic.gdx.math.Vector2
import com.badlogic.gdx.scenes.scene2d.Actor
import com.badlogic.gdx.scenes.scene2d.InputEvent
import com.badlogic.gdx.scenes.scene2d.InputListener
import com.badlogic.gdx.scenes.scene2d.Touchable
import com.badlogic.gdx.scenes.scene2d.actions.Actions
import com.badlogic.gdx.scenes.scene2d.ui.Widget
import com.badlogic.gdx.scenes.scene2d.ui.WidgetGroup
import com.liberator.wisoliter.game.actors.button.AButton
import com.liberator.wisoliter.game.manager.util.SoundUtil
import com.liberator.wisoliter.game.utils.SizeScaler
import com.liberator.wisoliter.game.utils.actor.setOnClickListenerByPolygon
import com.liberator.wisoliter.game.utils.runGDX
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine
import kotlin.math.round

fun Actor.setOnClickListener(
    soundUtil: SoundUtil? = null,
    block: (Actor) -> Unit
) {

    addListener(object : InputListener() {
        var isEnter = false

        override fun enter(event: InputEvent?, x: Float, y: Float, pointer: Int, fromActor: Actor?) {
            isEnter = true
        }
        override fun exit(event: InputEvent?, x: Float, y: Float, pointer: Int, toActor: Actor?) {
            isEnter = false
        }

        override fun touchDown(event: InputEvent?, x: Float, y: Float, pointer: Int, button: Int): Boolean {
            touchDragged(event, x, y, pointer)
            return true
        }

        override fun touchUp(event: InputEvent?, x: Float, y: Float, pointer: Int, button: Int) {
            if (isEnter) {
                soundUtil?.apply { play(click) }
                isEnter = false
                block(this@setOnClickListener)
            }
        }
    })
}

fun Actor.setOnClickListenerByPolygon(
    soundUtil: SoundUtil? = null,
    polygon: Polygon,
    radius: Int = 1,
    block: (Actor) -> Unit,
) {
    val touchPointDown = Vector2()
    val touchPointUp   = Vector2()

    addListener(object : InputListener() {
        var isEnter = false

        override fun touchDown(event: InputEvent?, x: Float, y: Float, pointer: Int, button: Int): Boolean {
            isEnter = polygon.contains(x, y)
            if (isEnter) {
                touchPointDown.set(round(x), round(y))
                touchDragged(event, x, y, pointer)
            }
            return isEnter
        }

        override fun touchDragged(event: InputEvent?, x: Float, y: Float, pointer: Int) {
            isEnter = polygon.contains(x, y)
        }

        override fun touchUp(event: InputEvent?, x: Float, y: Float, pointer: Int, button: Int) {
            if (isEnter) {
                isEnter = false

                touchPointUp.set(round(x), round(y))
                if (touchPointDown.x in (touchPointUp.x - radius..touchPointUp.x + radius) &&
                    touchPointDown.y in (touchPointUp.y - radius..touchPointUp.y + radius)) {

                    soundUtil?.apply { play(select) }
                    block(this@setOnClickListenerByPolygon)
                }
            }
        }
    })
}

fun Actor.setOnClickListenerWithBlock(
    soundUtil: SoundUtil? = null,
    touchDownBlock   : Actor.(x: Float, y: Float) -> Unit = { _, _ -> },
    touchDraggedBlock: Actor.(x: Float, y: Float) -> Unit = { _, _ -> },
    touchUpBlock     : Actor.(x: Float, y: Float) -> Unit = { _, _ -> },
    block: Actor.() -> Unit = {},
) {

    addListener(object : InputListener() {
        var isWithin = false

        override fun touchDown(event: InputEvent?, x: Float, y: Float, pointer: Int, button: Int): Boolean {
            touchDownBlock(x, y)
            touchDragged(event, x, y, pointer)
            soundUtil?.apply { play(click) }
            return true
        }

        override fun touchDragged(event: InputEvent?, x: Float, y: Float, pointer: Int) {
            touchDraggedBlock(x, y)
            isWithin = x in 0f..width && y in 0f..height
        }

        override fun touchUp(event: InputEvent?, x: Float, y: Float, pointer: Int, button: Int) {
            touchUpBlock(x, y)
            if (isWithin) {
                isWithin = false
                block()
            }
        }
    })
}

fun Actor.disable() = when(this) {
    is AButton -> disable()
    else       -> touchable = Touchable.disabled
}

fun Actor.enable() = when(this) {
    is AButton -> enable()
    else       -> touchable = Touchable.enabled
}

fun List<Actor>.setFillParent() {
    onEach { actor ->
        when (actor) {
            is Widget      -> actor.setFillParent(true)
            is WidgetGroup -> actor.setFillParent(true)
        }
    }
}

fun Actor.setBounds(position: Vector2, size: Vector2) {
    setBounds(position.x, position.y, size.x, size.y)
}

fun Actor.setBounds(vPosSize: PosSize) {
    setBounds(vPosSize.x, vPosSize.y, vPosSize.w, vPosSize.h)
}

fun Actor.setBoundsScaled(sizeScaler: SizeScaler, x: Float, y: Float, width: Float, height: Float) {
    setBounds(sizeScaler.scaled(x), sizeScaler.scaled(y), sizeScaler.scaled(width), sizeScaler.scaled(height))
}

fun Actor.setBoundsScaled(sizeScaler: SizeScaler, position: Vector2, size: Vector2) {
    setBoundsScaled(sizeScaler, position.x, position.y, size.x, size.y)
}

fun Actor.setSizeScaled(sizeScaler: SizeScaler, width: Float, height: Float) {
    setSize(sizeScaler.scaled(width), sizeScaler.scaled(height))
}

fun Actor.setPosition(position: Vector2) {
    setPosition(position.x, position.y)
}

fun Actor.setOrigin(vector: Vector2) {
    setOrigin(vector.x, vector.y)
}

fun Actor.animShow(time: Float=0f, block: () -> Unit = {}) {
    addAction(Actions.sequence(
        Actions.fadeIn(time),
        Actions.run(block)
    ))
}
fun Actor.animHide(time: Float=0f, block: () -> Unit = {}) {
    addAction(Actions.sequence(
        Actions.fadeOut(time),
        Actions.run(block)
    ))
}

// Anim Suspend
suspend fun Actor.animShowSuspend(time: Float = 0f, block: () -> Unit = {}) = suspendCoroutine<Unit> { continuation ->
    runGDX {
        animShow(time) {
            block()
            continuation.resume(Unit)
        }
    }
}

suspend fun Actor.animHideSuspend(time: Float = 0f, block: () -> Unit = {}) = suspendCoroutine<Unit> { continuation ->
    runGDX {
        animHide(time) {
            block()
            continuation.resume(Unit)
        }
    }
}

suspend fun Actor.animMoveToSuspend(x: Float, y: Float, time: Float = 0f, interpolation: Interpolation = Interpolation.linear, block: () -> Unit = {}) = suspendCoroutine<Unit> { continuation ->
    runGDX {
        addAction(Actions.sequence(
            Actions.moveTo(x, y, time, interpolation),
            Actions.run {
                block()
                continuation.resume(Unit)
            }
        ))
    }
}

data class PosSize(val x: Float, val y: Float, val w: Float, val h: Float)