package com.eqcpert.ginvestrum.push

data class Push(
    val icon: Int,
    val title: String,
    val text: String
)
