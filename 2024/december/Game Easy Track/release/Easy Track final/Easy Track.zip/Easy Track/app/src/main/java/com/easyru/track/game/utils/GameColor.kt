package com.easyru.track.game.utils

import com.badlogic.gdx.graphics.Color

object GameColor {

    val background: Color = Color.valueOf("565656")

    val black_24: Color = Color.valueOf("242424")

}