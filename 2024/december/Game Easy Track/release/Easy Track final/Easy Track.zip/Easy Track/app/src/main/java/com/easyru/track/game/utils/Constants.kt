package com.easyru.track.game.utils

const val WIDTH_UI  = 803f
const val HEIGHT_UI = 1739f

const val TIME_ANIM_SCREEN = 0.25f