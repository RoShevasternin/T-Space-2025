package com.funkun.kylkan.game.utils

const val WIDTH_UI  = 1011f
const val HEIGHT_UI = 2194f

const val TIME_ANIM_SCREEN = 0.27f