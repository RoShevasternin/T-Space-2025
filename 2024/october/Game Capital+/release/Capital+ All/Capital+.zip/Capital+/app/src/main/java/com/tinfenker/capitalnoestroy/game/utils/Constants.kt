package com.tinfenker.capitalnoestroy.game.utils

const val WIDTH_UI  = 774f
const val HEIGHT_UI = 1680f

const val TIME_ANIM = 0.275f