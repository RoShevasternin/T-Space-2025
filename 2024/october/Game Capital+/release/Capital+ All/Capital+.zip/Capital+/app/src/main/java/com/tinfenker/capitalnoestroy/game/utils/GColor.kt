package com.tinfenker.capitalnoestroy.game.utils

import com.badlogic.gdx.graphics.Color

object GColor {

    val yellow    = Color.valueOf("FFDD2D")
    val gray      = Color.valueOf("3E3F3E")
    val grayLight = Color.valueOf("5F5F5F")
    val grayWhite = Color.valueOf("B3B3B3")

}