package com.tinfenker.capitalnoestroy.game.actors.dataPanel

import com.badlogic.gdx.scenes.scene2d.Actor
import com.badlogic.gdx.scenes.scene2d.ui.Image
import com.badlogic.gdx.scenes.scene2d.ui.Label
import com.badlogic.gdx.utils.Align
import com.github.tommyettinger.textra.Styles.LabelStyle
import com.github.tommyettinger.textra.TypingLabel
import com.tinfenker.capitalnoestroy.game.actors.AButton
import com.tinfenker.capitalnoestroy.game.actors.progress.AYellowProgress
import com.tinfenker.capitalnoestroy.game.utils.GColor
import com.tinfenker.capitalnoestroy.game.utils.actor.setOnClickListener
import com.tinfenker.capitalnoestroy.game.utils.advanced.AdvancedGroup
import com.tinfenker.capitalnoestroy.game.utils.advanced.AdvancedScreen
import com.tinfenker.capitalnoestroy.game.utils.runGDX
import com.tinfenker.capitalnoestroy.game.utils.toBalance
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

class ABigData(
    override val screen: AdvancedScreen,
    val title  : String,
    val summa  : Int,
    val period : Int,
    val percent: Int,
    val ls37   : Label.LabelStyle,
) : AdvancedGroup() {

    private val dohod = (summa * (percent / 100f)).roundToInt()

    private val textSumma   = "${summa.toBalance} [#${GColor.grayWhite}]{SIZE=%95}₽"
    private val textPeriod  = "$period [#${GColor.grayWhite}]{SIZE=%95}${getMonth()}"
    private val textPercent = "$percent[#${GColor.grayWhite}]{SIZE=%95}%"
    private val textDohod   = "${dohod.toBalance} [#${GColor.grayWhite}]{SIZE=%95}₽"

    private val lsTyping37 = LabelStyle(ls37)

    private val aRemove    = Actor()
    private val aEdit      = Actor()
    private val lblTitle   = Label(title, ls37)
    private val lblSumma   = TypingLabel(textSumma, lsTyping37)
    private val lblPeriod  = TypingLabel(textPeriod, lsTyping37)
    private val lblPercent = TypingLabel(textPercent, lsTyping37)
    private val lblDohod   = TypingLabel(textDohod, lsTyping37)

    var blockRemove: () -> Unit = {}
    var blockEdit  : () -> Unit = {}

    override fun addActorsOnGroup() {
        addAndFillActor(Image(screen.game.all.PANEL_DATA_BIG))
        addLbls()
        addBtns()
    }

    private fun addLbls() {
        addActors(lblTitle, lblSumma, lblPeriod, lblPercent, lblDohod)
        lblTitle.apply {
            setBounds(231f,451f,300f,26f)
            setAlignment(Align.center)
        }
        lblSumma.setBounds(171f,299f,203f,26f)
        lblPeriod.setBounds(415f,299f,168f,26f)
        lblPercent.setBounds(171f,157f,64f,26f)
        lblDohod.setBounds(415f,157f,152f,26f)
    }

    private fun addBtns() {
        addActors(aRemove, aEdit)
        aRemove.apply {
            setBounds(123f,58f,233f,92f)
            setOnClickListener(screen.game.soundUtil) {
                blockRemove()
            }
        }
        aEdit.apply {
            setBounds(359f,58f,233f,92f)
            setOnClickListener(screen.game.soundUtil) {
                blockEdit()
            }
        }
    }

    // Logic -------------------------------------------------------------------

    private fun getMonth() = when {
        period == 1            -> "месяц"
        period in (2..4) -> "месяца"
        else                   -> "месяцев"
    }

}