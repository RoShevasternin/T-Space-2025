package com.eqcpert.ginvestrum

import android.app.Application
import android.content.Context
import android.os.StrictMode
import com.adjust.sdk.Adjust
import com.adjust.sdk.AdjustConfig
import com.eqcpert.ginvestrum.util.log
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.security.cert.X509Certificate
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager

lateinit var appContext: Context private set

class App: Application() {

    override fun onCreate() {
        super.onCreate()

        appContext = applicationContext
    }


}