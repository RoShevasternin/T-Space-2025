package com.proccaptald.proffesionalestic.game.utils

import com.badlogic.gdx.graphics.Color

object GColor {

    val background = Color.valueOf("F6F6F6")
    val black      = Color.valueOf("001725")

}