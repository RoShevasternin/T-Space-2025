package com.proccaptald.proffesionalestic.game.utils

const val WIDTH_UI  = 657f
const val HEIGHT_UI = 1422f

const val TIME_ANIM = 0.15f