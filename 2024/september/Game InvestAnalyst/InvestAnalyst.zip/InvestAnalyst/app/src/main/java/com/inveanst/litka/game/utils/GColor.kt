package com.inveanst.litka.game.utils

import com.badlogic.gdx.graphics.Color

object GColor {

    val background = Color.valueOf("F6F6F6")
    val green      = Color.valueOf("189F3E")
    val text       = Color.valueOf("22333F")
    val answerM    = Color.valueOf("666666")

}