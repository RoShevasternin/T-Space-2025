package com.inveanst.litka.game.utils

const val WIDTH_UI  = 375f
const val HEIGHT_UI = 812f

const val TIME_ANIM = 0.25f

const val FONT_SCALE = 3

