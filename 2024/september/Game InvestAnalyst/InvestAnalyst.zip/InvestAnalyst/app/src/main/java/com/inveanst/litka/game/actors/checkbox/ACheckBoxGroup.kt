package com.fansipan.stickman.shadow.k.game.actors.checkbox

import com.inveanst.litka.game.actors.checkbox.ACheckBox

class ACheckBoxGroup {
    var currentCheckedCheckBox: ACheckBox? = null
}