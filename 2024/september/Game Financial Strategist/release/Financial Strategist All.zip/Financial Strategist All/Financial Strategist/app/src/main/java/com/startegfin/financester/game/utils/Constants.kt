package com.startegfin.financester.game.utils

const val WIDTH_UI  = 753f
const val HEIGHT_UI = 1630f

const val TIME_ANIM = 0.3f