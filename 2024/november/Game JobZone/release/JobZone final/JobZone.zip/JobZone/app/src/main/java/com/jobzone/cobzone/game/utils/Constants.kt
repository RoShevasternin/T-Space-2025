package com.jobzone.cobzone.game.utils

const val WIDTH_UI  = 731f
const val HEIGHT_UI = 1587f

const val TIME_ANIM_SCREEN = 0.4f