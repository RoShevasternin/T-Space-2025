package com.progressmas.mastermas.game.actors.dialog

import com.badlogic.gdx.scenes.scene2d.Actor
import com.badlogic.gdx.scenes.scene2d.actions.Actions
import com.badlogic.gdx.scenes.scene2d.ui.Image
import com.progressmas.mastermas.game.actors.Mask
import com.progressmas.mastermas.game.utils.TIME_ANIM
import com.progressmas.mastermas.game.utils.WIDTH_UI
import com.progressmas.mastermas.game.utils.actor.animHide
import com.progressmas.mastermas.game.utils.actor.setOnClickListener
import com.progressmas.mastermas.game.utils.advanced.AdvancedGroup
import com.progressmas.mastermas.game.utils.advanced.AdvancedScreen
import com.progressmas.mastermas.game.utils.runGDX
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch

class ADialogInvest(
    override val screen: AdvancedScreen,
    screenTypeIndex: Int,
    investmentIndex: Int,
): AdvancedGroup() {

    private val imgBackground = Image(screen.game.all.listAllDialogInvest[investmentIndex][screenTypeIndex])

    override fun addActorsOnGroup() {
        color.a = 0f
        addAndFillActor(imgBackground)
        val aX = Actor()
        addActor(aX)
        aX.setBounds(591f, 494f, 89f, 89f)
        aX.setOnClickListener(screen.game.soundUtil) {
            animHide(TIME_ANIM) {
                dispose()
                addAction(Actions.removeActor())
            }
        }
    }

}