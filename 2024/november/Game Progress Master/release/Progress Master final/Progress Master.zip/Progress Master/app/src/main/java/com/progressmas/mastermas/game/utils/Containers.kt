package com.progressmas.mastermas.game.utils


data class ContainerXP(var valueXP: Float)

data class ContainerBlockXP(var block: Block)