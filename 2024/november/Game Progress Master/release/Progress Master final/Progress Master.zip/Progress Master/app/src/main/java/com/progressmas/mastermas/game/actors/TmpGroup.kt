package com.progressmas.mastermas.game.actors

import com.progressmas.mastermas.game.utils.advanced.AdvancedGroup
import com.progressmas.mastermas.game.utils.advanced.AdvancedScreen

class TmpGroup(
    override val screen: AdvancedScreen,
) : AdvancedGroup() {

    override fun getPrefHeight(): Float {
        return height
    }

    override fun addActorsOnGroup() {

    }

}