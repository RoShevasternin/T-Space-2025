package com.clickandbuild.motors.game.utils

const val WIDTH_UI  = 877f
const val HEIGHT_UI = 1899f

const val TIME_ANIM = 0.2f