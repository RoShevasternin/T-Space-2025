package com.clickandbuild.motors.game.utils

import com.badlogic.gdx.graphics.Color

object GColor {

    val text = Color.valueOf("383636")

}