package com.uxo.monaxa.game.actors.checkbox

import com.clickandbuild.motors.game.actors.checkbox.ACheckBox

class ACheckBoxGroup {
    var currentCheckedCheckBox: ACheckBox? = null
}