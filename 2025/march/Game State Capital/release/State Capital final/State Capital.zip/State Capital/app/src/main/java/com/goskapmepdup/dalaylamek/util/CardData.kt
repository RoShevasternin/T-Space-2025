package com.goskapmepdup.dalaylamek.util

data class CardData(
    val name: String,
    val period: String,
    val percent: String,
    val amount: String,
    val profit: String
)
