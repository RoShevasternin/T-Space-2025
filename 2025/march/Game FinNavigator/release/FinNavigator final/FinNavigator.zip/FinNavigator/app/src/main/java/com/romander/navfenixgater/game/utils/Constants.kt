package com.romander.navfenixgater.game.utils

const val WIDTH_UI  = 692f
const val HEIGHT_UI = 1502f

const val TIME_ANIM_SCREEN = 0.125f