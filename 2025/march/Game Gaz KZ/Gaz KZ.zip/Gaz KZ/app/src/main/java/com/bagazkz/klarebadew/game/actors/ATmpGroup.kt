package com.bagazkz.klarebadew.game.actors

import com.bagazkz.klarebadew.game.utils.advanced.AdvancedGroup
import com.bagazkz.klarebadew.game.utils.advanced.AdvancedScreen

class ATmpGroup(
    override val screen: AdvancedScreen,
): AdvancedGroup() {

    override fun addActorsOnGroup() {}

}