package com.bagazkz.klarebadew.game.utils

const val WIDTH_UI  = 957f
const val HEIGHT_UI = 2077f

const val TIME_ANIM_SCREEN = 0.25f