package com.rugosbon.pybonesrus.game.data

data class DataTest(
    val listQ : List<String>,
    val listA : List<List<String>>,
)
