package com.cryonetpoint.ecsporush.game.utils

import com.badlogic.gdx.graphics.Color

object GameColor {

    val background: Color = Color.valueOf("161616")

    val yellow  : Color = Color.valueOf("FFD633")

}