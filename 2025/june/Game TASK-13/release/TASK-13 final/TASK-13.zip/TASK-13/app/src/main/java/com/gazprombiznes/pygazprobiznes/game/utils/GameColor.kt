package com.gazprombiznes.pygazprobiznes.game.utils

import com.badlogic.gdx.graphics.Color

object GameColor {

    val background: Color = Color.valueOf("000000")

    val blue : Color = Color.valueOf("009CCF")

}