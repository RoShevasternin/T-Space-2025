package com.gazprombiznes.pygazprobiznes.game.utils

const val WIDTH_UI  = 608f
const val HEIGHT_UI = 1324f

const val TIME_ANIM_SCREEN = 0.135f