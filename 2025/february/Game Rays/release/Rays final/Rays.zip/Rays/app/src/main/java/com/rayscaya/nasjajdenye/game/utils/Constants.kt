package com.rayscaya.nasjajdenye.game.utils

const val WIDTH_UI  = 928f
const val HEIGHT_UI = 2014f

const val TIME_ANIM_SCREEN = 0.200f