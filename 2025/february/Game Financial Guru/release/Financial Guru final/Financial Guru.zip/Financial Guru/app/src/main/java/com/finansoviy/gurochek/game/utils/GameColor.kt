package com.finansoviy.gurochek.game.utils

import com.badlogic.gdx.graphics.Color

object GameColor {

    val background: Color = Color.valueOf("FFFFFF")

    val black_1E : Color = Color.valueOf("1E222E")
}