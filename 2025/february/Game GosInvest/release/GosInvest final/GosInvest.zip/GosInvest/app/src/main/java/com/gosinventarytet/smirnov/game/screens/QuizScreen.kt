package com.gosinventarytet.smirnov.game.screens

import com.gosinventarytet.smirnov.game.actors.main.AMainQuiz
import com.gosinventarytet.smirnov.game.utils.Block
import com.gosinventarytet.smirnov.game.utils.advanced.AdvancedMainScreen
import com.gosinventarytet.smirnov.game.utils.advanced.AdvancedStage

class QuizScreen: AdvancedMainScreen() {

    override val aMain = AMainQuiz(this)

    override fun AdvancedStage.addActorsOnStageUI() {
        addMain()
    }

    override fun hideScreen(block: Block) {
        aMain.animHideMain { block.invoke() }
    }

    // Actors UI------------------------------------------------------------------------

    override fun AdvancedStage.addMain() {
        addAndFillActor(aMain)
    }

}