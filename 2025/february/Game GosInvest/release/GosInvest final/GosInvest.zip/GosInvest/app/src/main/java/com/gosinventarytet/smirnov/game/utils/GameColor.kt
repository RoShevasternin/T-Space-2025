package com.gosinventarytet.smirnov.game.utils

import com.badlogic.gdx.graphics.Color

object GameColor {

    val background: Color = Color.valueOf("020C22")

    val blue_2E : Color = Color.valueOf("2E59B7")

}