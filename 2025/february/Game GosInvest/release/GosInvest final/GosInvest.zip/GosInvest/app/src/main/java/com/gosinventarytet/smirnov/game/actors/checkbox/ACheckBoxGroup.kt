package com.uxo.monaxa.game.actors.checkbox

import com.gosinventarytet.smirnov.game.actors.checkbox.ACheckBox

class ACheckBoxGroup {
    var currentCheckedCheckBox: ACheckBox? = null
}