package com.gosinventarytet.smirnov.game.data

data class DataQuiz(
    val quest  : String,
    val listAns: List<String>,
)
