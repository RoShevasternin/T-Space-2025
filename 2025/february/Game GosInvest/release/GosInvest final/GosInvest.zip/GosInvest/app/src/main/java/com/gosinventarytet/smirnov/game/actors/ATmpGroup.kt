package com.gosinventarytet.smirnov.game.actors

import com.gosinventarytet.smirnov.game.utils.advanced.AdvancedGroup
import com.gosinventarytet.smirnov.game.utils.advanced.AdvancedScreen

class ATmpGroup(
    override val screen: AdvancedScreen,
): AdvancedGroup() {

    override fun addActorsOnGroup() {}

}