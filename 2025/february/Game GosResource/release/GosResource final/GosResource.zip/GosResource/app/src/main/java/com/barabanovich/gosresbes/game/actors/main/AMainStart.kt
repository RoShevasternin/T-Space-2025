package com.barabanovich.gosresbes.game.actors.main

import com.badlogic.gdx.scenes.scene2d.ui.Image
import com.barabanovich.gosresbes.game.actors.button.AButton
import com.barabanovich.gosresbes.game.screens.CategoryScreen
import com.barabanovich.gosresbes.game.screens.StartScreen
import com.barabanovich.gosresbes.game.utils.Block
import com.barabanovich.gosresbes.game.utils.TIME_ANIM_SCREEN
import com.barabanovich.gosresbes.game.utils.actor.animDelay
import com.barabanovich.gosresbes.game.utils.actor.animHide
import com.barabanovich.gosresbes.game.utils.actor.animShow
import com.barabanovich.gosresbes.game.utils.advanced.AdvancedMainGroup
import com.barabanovich.gosresbes.game.utils.gdxGame

class AMainStart(
    override val screen: StartScreen,
): AdvancedMainGroup() {

    private val imgPhoto = Image(gdxGame.assetsAll.prognoz)

    override fun addActorsOnGroup() {
        color.a = 0f

        addImgPhoto()

        animShowMain()
    }

    // Actors ------------------------------------------------------------------------

    private fun addImgPhoto() {
        addActor(imgPhoto)
        imgPhoto.setBounds(54f, 456f, 905f, 319f)

        this.animDelay(2f) {
            screen.hideScreen {
                gdxGame.navigationManager.navigate(CategoryScreen::class.java.name)
            }
        }
    }

    // Anim ------------------------------------------------

    override fun animShowMain(blockEnd: Block) {
        this.animShow(TIME_ANIM_SCREEN)
        this.animDelay(TIME_ANIM_SCREEN) { blockEnd.invoke() }
    }

    override fun animHideMain(blockEnd: Block) {
        this.animHide(TIME_ANIM_SCREEN)
        this.animDelay(TIME_ANIM_SCREEN) { blockEnd.invoke() }
    }

}