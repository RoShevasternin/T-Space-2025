package com.barabanovich.gosresbes.game.data

data class DataQuiz(
    val listQ : List<String>,
    val listA : List<List<String>>,
)
