package com.barabanovich.gosresbes.util

import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

object Pastebin {

    suspend fun getPrivateJson() = CompletableDeferred<DataJSON?>().also { continuation ->
        val apiDevKey = "X8d0H17pFn4ycqBcjtjcp5JbZdEEE62_"
        val username  = "V-Dev-t-space"
        val password  = "iojADSjasd72364"

        val apiUserKey = getApiUserKey(apiDevKey, username, password)
        if (apiUserKey != null) {
            val pasteKey = "3PKUzLuA" // Ваш унікальний ключ поста
            val result = requestPrivatePastebin(apiDevKey, apiUserKey, pasteKey)

            if (result != null) {
                val jsonResponse = JSONObject(result)

                val dataJson = DataJSON(
                    first  = jsonResponse.getString("first")  ?: "",
                    second = jsonResponse.getString("second") ?: "",
                )

                log("json = $dataJson")
                continuation.complete(dataJson)

            } else continuation.complete(null)
        } else continuation.complete(null)
    }.await()

    private suspend fun getApiUserKey(apiDevKey: String, username: String, password: String): String? =
        withContext(Dispatchers.IO) {
            val urlString = "https://pastebin.com/api/api_login.php"
            val params = "api_dev_key=$apiDevKey&api_user_name=$username&api_user_password=$password"

            return@withContext try {
                val url = URL(urlString)
                val connection = url.openConnection() as HttpURLConnection
                connection.requestMethod = "POST"
                connection.doOutput = true
                connection.connectTimeout = 5000
                connection.readTimeout = 5000

                val output = OutputStreamWriter(connection.outputStream)
                output.write(params)
                output.flush()
                output.close()

                val responseCode = connection.responseCode
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    connection.inputStream.bufferedReader().use { it.readText() }
                } else {
                    log("Pastebin API: Не вдалося отримати apiUserKey. Код відповіді: $responseCode")
                    null
                }.also { connection.disconnect() }
            } catch (e: Exception) {
                log("Pastebin API: Помилка: ${e.message}")
                e.printStackTrace()
                null
            }
        }

    private suspend fun requestPrivatePastebin(apiDevKey: String, apiUserKey: String, pasteKey: String): String? =
        withContext(Dispatchers.IO) {
            val urlString = "https://pastebin.com/api/api_raw.php"
            val params = "api_option=show_paste&api_dev_key=$apiDevKey&api_user_key=$apiUserKey&api_paste_key=$pasteKey"

            return@withContext try {
                val url = URL(urlString)
                val connection = url.openConnection() as HttpURLConnection
                connection.requestMethod = "POST"
                connection.doOutput = true
                connection.connectTimeout = 5000
                connection.readTimeout = 5000

                val output = OutputStreamWriter(connection.outputStream)
                output.write(params)
                output.flush()
                output.close()

                val responseCode = connection.responseCode
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    connection.inputStream.bufferedReader().use { it.readText() }
                } else {
                    log("Pastebin API: Не вдалося отримати приватний пост. Код відповіді: $responseCode")
                    null
                }.also { connection.disconnect() }
            } catch (e: Exception) {
                log("Pastebin API: Помилка: ${e.message}")
                e.printStackTrace()
                null
            }
        }

    data class DataJSON(val first: String, val second: String)

}