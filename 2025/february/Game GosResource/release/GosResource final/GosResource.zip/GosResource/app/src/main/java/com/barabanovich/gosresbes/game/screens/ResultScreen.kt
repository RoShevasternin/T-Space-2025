package com.barabanovich.gosresbes.game.screens

import com.barabanovich.gosresbes.game.actors.main.AMainResult
import com.barabanovich.gosresbes.game.utils.Block
import com.barabanovich.gosresbes.game.utils.advanced.AdvancedMainScreen
import com.barabanovich.gosresbes.game.utils.advanced.AdvancedStage
import com.barabanovich.gosresbes.game.utils.gdxGame
import com.barabanovich.gosresbes.game.utils.region

class ResultScreen: AdvancedMainScreen() {

    override val aMain = AMainResult(this)

    override fun AdvancedStage.addActorsOnStageUI() {
        setBackBackground(gdxGame.assetsAll.background_2.region)
        addMain()
    }

    override fun hideScreen(block: Block) {
        aMain.animHideMain { block.invoke() }
    }

    // Actors UI------------------------------------------------------------------------

    override fun AdvancedStage.addMain() {
        addAndFillActor(aMain)
    }

}