package com.ayrym.invetigen.game.actors

import com.ayrym.invetigen.game.actors.checkbox.ACheckBox
import com.ayrym.invetigen.game.utils.Acts
import com.ayrym.invetigen.game.utils.SizeScaler
import com.ayrym.invetigen.game.utils.actor.PosSize
import com.ayrym.invetigen.game.utils.actor.animDelay
import com.ayrym.invetigen.game.utils.actor.disable
import com.ayrym.invetigen.game.utils.actor.setBoundsScaled
import com.ayrym.invetigen.game.utils.advanced.AdvancedGroup
import com.ayrym.invetigen.game.utils.advanced.AdvancedScreen
import com.ayrym.invetigen.game.utils.gdxGame
import com.badlogic.gdx.math.Interpolation
import com.badlogic.gdx.scenes.scene2d.ui.Image
import com.badlogic.gdx.scenes.scene2d.ui.Label
import com.badlogic.gdx.utils.Align
import com.uxo.monaxa.game.actors.checkbox.ACheckBoxGroup

class ABoxCenter(
    override val screen: AdvancedScreen,
    text: String,
    ls: Label.LabelStyle,
    val cbg: ACheckBoxGroup,
): AdvancedGroup() {

    private val box = ACheckBox(screen, ACheckBox.Type.CIRCLE)
    private val lbl = Label(text, ls)

    override fun addActorsOnGroup() {
        addAndFillActors(box, lbl)

        box.checkBoxGroup = cbg
        lbl.setAlignment(Align.center)
        children.onEach { it.disable() }
    }


    fun select() {
        box.check()
    }



}