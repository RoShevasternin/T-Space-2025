package com.ayrym.invetigen.game.actors

import com.ayrym.invetigen.game.utils.advanced.AdvancedGroup
import com.ayrym.invetigen.game.utils.advanced.AdvancedScreen

class ATmpGroup(
    override val screen: AdvancedScreen,
): AdvancedGroup() {

    override fun addActorsOnGroup() {}

}