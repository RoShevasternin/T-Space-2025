package com.uxo.monaxa.game.actors.checkbox

import com.ayrym.invetigen.game.actors.checkbox.ACheckBox

class ACheckBoxGroup {
    var currentCheckedCheckBox: ACheckBox? = null
}