package com.cinvestor.crotcevni.game.utils

import com.badlogic.gdx.graphics.Color

object GameColor {

    val background: Color = Color.valueOf("666D6F")

    val black_44 : Color = Color.valueOf("444444")

}