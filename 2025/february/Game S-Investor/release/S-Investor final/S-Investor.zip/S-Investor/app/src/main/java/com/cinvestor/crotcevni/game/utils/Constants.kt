package com.cinvestor.crotcevni.game.utils

const val WIDTH_UI  = 932f
const val HEIGHT_UI = 2019f

const val TIME_ANIM_SCREEN = 0.375f