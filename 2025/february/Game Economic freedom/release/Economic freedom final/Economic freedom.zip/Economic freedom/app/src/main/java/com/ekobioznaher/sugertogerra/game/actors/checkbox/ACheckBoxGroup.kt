package com.ekobioznaher.sugertogerra.game.actors.checkbox

class ACheckBoxGroup {
    var currentCheckedCheckBox: ACheckBox? = null
}