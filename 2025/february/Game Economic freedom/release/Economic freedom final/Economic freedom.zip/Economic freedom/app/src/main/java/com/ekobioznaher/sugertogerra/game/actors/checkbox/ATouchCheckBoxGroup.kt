package com.ekobioznaher.sugertogerra.game.actors.checkbox

class ATouchCheckBoxGroup {
    var currentCheckedCheckBox: ATouchCheckBox? = null
}