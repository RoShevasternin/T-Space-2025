package com.bobrevsc.tkarierraperbola.game.utils

const val WIDTH_UI  = 1113f
const val HEIGHT_UI = 2411f

const val TIME_ANIM = 0.150f