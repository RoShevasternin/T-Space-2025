package com.sberigatelny.finexpertaizer.game.data

data class DataQuiz(
    val listQ : List<String>,
    val listA : List<List<String>>,
)
