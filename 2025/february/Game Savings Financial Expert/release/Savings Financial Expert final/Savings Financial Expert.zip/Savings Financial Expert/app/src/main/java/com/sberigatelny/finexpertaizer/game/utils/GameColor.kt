package com.sberigatelny.finexpertaizer.game.utils

import com.badlogic.gdx.graphics.Color

object GameColor {

    val background: Color = Color.valueOf("FFFFFF")

    val black_44 : Color = Color.valueOf("444444")
}