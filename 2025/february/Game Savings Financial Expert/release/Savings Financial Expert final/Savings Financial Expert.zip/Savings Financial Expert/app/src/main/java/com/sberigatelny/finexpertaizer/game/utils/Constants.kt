package com.sberigatelny.finexpertaizer.game.utils

const val WIDTH_UI  = 985f
const val HEIGHT_UI = 2133f

const val TIME_ANIM_SCREEN = 0.37f