package com.busiknesik.pomeshnek.game.utils

const val WIDTH_UI  = 1190f
const val HEIGHT_UI = 2585f

const val TIME_ANIM_SCREEN = 0.2f