package com.busiknesik.pomeshnek.game.utils.actor

import com.badlogic.gdx.math.Vector2
import com.badlogic.gdx.scenes.scene2d.Actor
import com.badlogic.gdx.scenes.scene2d.InputEvent
import com.badlogic.gdx.scenes.scene2d.InputListener
import com.badlogic.gdx.scenes.scene2d.Touchable
import com.badlogic.gdx.scenes.scene2d.actions.Actions
import com.badlogic.gdx.scenes.scene2d.ui.Widget
import com.badlogic.gdx.scenes.scene2d.ui.WidgetGroup
import com.busiknesik.pomeshnek.game.actors.button.AButton
import com.busiknesik.pomeshnek.game.manager.util.SoundUtil
import com.busiknesik.pomeshnek.game.utils.SizeScaler
import kotlin.math.round

fun Actor.setOnClickListener(
    soundUtil: SoundUtil? = null,
    block: (Actor) -> Unit
) {

    addListener(object : InputListener() {
        var isEnter = false

        override fun enter(event: InputEvent?, x: Float, y: Float, pointer: Int, fromActor: Actor?) {
            isEnter = true
        }
        override fun exit(event: InputEvent?, x: Float, y: Float, pointer: Int, toActor: Actor?) {
            isEnter = false
        }

        override fun touchDown(event: InputEvent?, x: Float, y: Float, pointer: Int, button: Int): Boolean {
            touchDragged(event, x, y, pointer)
            return true
        }

        override fun touchUp(event: InputEvent?, x: Float, y: Float, pointer: Int, button: Int) {
            if (isEnter) {
                soundUtil?.apply { play(click) }
                isEnter = false
                block(this@setOnClickListener)
            }
        }
    })
}

fun Actor.setOnTouchListener(soundUtil: SoundUtil? = null, radius: Int = 1, block: (Actor) -> Unit) {
    val touchPointDown = Vector2()
    val touchPointUp   = Vector2()
    addListener(object : InputListener() {
        override fun touchDown(event: InputEvent?, x: Float, y: Float, pointer: Int, button: Int): Boolean {
            touchPointDown.set(round(x), round(y))
            return true
        }
        override fun touchUp(event: InputEvent?, x: Float, y: Float, pointer: Int, button: Int) {
            touchPointUp.set(round(x), round(y))
            if (touchPointDown.x in (touchPointUp.x - radius..touchPointUp.x + radius) &&
                touchPointDown.y in (touchPointUp.y - radius..touchPointUp.y + radius)
            ) {
                soundUtil?.apply { play(click) }
                block(this@setOnTouchListener)
            }
        }
    })
}

fun Actor.disable() = when(this) {
    is AButton -> disable()
    else       -> touchable = Touchable.disabled
}

fun Actor.enable() = when(this) {
    is AButton -> enable()
    else       -> touchable = Touchable.enabled
}

fun List<Actor>.setFillParent() {
    onEach { actor ->
        when (actor) {
            is Widget      -> actor.setFillParent(true)
            is WidgetGroup -> actor.setFillParent(true)
        }
    }
}

fun Actor.setBounds(position: Vector2, size: Vector2) {
    setBounds(position.x, position.y, size.x, size.y)
}

fun Actor.setBounds(vPosSize: PosSize) {
    setBounds(vPosSize.x, vPosSize.y, vPosSize.w, vPosSize.h)
}

fun Actor.setBoundsScaled(sizeScaler: SizeScaler, x: Float, y: Float, width: Float, height: Float) {
    setBounds(sizeScaler.scaled(x), sizeScaler.scaled(y), sizeScaler.scaled(width), sizeScaler.scaled(height))
}

fun Actor.setBoundsScaled(sizeScaler: SizeScaler, position: Vector2, size: Vector2) {
    setBoundsScaled(sizeScaler, position.x, position.y, size.x, size.y)
}

fun Actor.setSizeScaled(sizeScaler: SizeScaler, width: Float, height: Float) {
    setSize(sizeScaler.scaled(width), sizeScaler.scaled(height))
}

fun Actor.setPosition(position: Vector2) {
    setPosition(position.x, position.y)
}

fun Actor.setOrigin(vector: Vector2) {
    setOrigin(vector.x, vector.y)
}

fun Actor.animShow(time: Float=0f, block: () -> Unit = {}) {
    addAction(Actions.sequence(
        Actions.fadeIn(time),
        Actions.run(block)
    ))
}
fun Actor.animHide(time: Float=0f, block: () -> Unit = {}) {
    addAction(Actions.sequence(
        Actions.fadeOut(time),
        Actions.run(block)
    ))
}

data class PosSize(val x: Float, val y: Float, val w: Float, val h: Float)