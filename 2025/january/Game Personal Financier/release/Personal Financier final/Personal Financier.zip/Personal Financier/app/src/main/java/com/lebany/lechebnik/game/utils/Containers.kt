package com.lebany.lechebnik.game.utils


data class ContainerXP(var valueXP: Float)

data class ContainerBlockXP(var block: Block)