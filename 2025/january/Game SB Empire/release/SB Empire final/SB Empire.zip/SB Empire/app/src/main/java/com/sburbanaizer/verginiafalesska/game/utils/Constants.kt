package com.sburbanaizer.verginiafalesska.game.utils

const val WIDTH_UI  = 713f
const val HEIGHT_UI = 1549f

const val TIME_ANIM_SCREEN = 0.2f