package com.pulser.dengy.game.utils

const val WIDTH_UI  = 1175f
const val HEIGHT_UI = 2552f

const val TIME_ANIM_SCREEN = 0.263f