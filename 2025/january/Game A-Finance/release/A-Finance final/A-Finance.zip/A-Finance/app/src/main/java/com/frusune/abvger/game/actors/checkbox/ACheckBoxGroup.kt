package com.frusune.abvger.game.actors.checkbox

class ACheckBoxGroup {
    var currentCheckedCheckBox: ACheckBox? = null
}