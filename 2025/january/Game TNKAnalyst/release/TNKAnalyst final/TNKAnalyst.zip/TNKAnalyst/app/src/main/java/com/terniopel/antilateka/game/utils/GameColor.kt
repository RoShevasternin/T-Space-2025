package com.terniopel.antilateka.game.utils

import com.badlogic.gdx.graphics.Color

object GameColor {

    val white: Color = Color.valueOf("FFFFFF")

    val green_B1: Color = Color.valueOf("E7D9BF")
    val green_0D: Color = Color.valueOf("A27F00")
    val black_0B: Color = Color.valueOf("0B2005")

}