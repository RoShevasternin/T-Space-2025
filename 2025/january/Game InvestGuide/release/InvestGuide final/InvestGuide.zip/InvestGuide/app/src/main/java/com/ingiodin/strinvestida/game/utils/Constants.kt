package com.ingiodin.strinvestida.game.utils

const val WIDTH_UI  = 1013f
const val HEIGHT_UI = 2194f

const val TIME_ANIM = 0.126f