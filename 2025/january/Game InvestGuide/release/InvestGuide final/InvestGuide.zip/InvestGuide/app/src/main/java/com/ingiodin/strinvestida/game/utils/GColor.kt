package com.ingiodin.strinvestida.game.utils

import com.badlogic.gdx.graphics.Color

object GColor {

    val text = Color.valueOf("383636")

}