package com.kaskazer.kazmuchero.game.utils

const val WIDTH_UI  = 1042f
const val HEIGHT_UI = 2258f

const val TIME_ANIM = 0.249f