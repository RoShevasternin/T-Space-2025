package com.ogonechek.putinvestor.game.utils

const val WIDTH_UI  = 1361f
const val HEIGHT_UI = 2956f

const val TIME_ANIM_SCREEN = 0.2f