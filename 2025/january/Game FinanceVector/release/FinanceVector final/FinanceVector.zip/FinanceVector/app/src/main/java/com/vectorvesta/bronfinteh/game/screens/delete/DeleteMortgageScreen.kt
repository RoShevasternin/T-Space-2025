package com.vectorvesta.bronfinteh.game.screens.delete

import com.vectorvesta.bronfinteh.game.actors.main.delete.AMainDeleteMortgage
import com.vectorvesta.bronfinteh.game.utils.Block
import com.vectorvesta.bronfinteh.game.utils.advanced.AdvancedMainScreen
import com.vectorvesta.bronfinteh.game.utils.advanced.AdvancedStage

class DeleteMortgageScreen: AdvancedMainScreen() {

    override val aMain = AMainDeleteMortgage(this)

    override fun AdvancedStage.addActorsOnStageUI() {
        addMain()
    }

    override fun hideScreen(block: Block) {
        aMain.animHideMain { block.invoke() }
    }

    // Actors UI------------------------------------------------------------------------

    override fun AdvancedStage.addMain() {
        addAndFillActor(aMain)
    }

}