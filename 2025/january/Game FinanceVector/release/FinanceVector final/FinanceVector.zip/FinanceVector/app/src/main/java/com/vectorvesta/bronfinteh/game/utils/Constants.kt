package com.vectorvesta.bronfinteh.game.utils

const val WIDTH_UI  = 900f
const val HEIGHT_UI = 1955f

const val TIME_ANIM_SCREEN = 0.220f