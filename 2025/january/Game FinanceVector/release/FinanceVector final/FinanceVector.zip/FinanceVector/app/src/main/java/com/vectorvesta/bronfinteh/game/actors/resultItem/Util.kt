package com.vectorvesta.bronfinteh.game.actors.resultItem

val GLOBAL_listTitleLeasing = listOf(
    "Ежемесячная сумма выплат",
    "Итоговая сумма выплат",
    "Стоимость объекта",
    "Комиссии",
    "Остаток стоимости объекта",
)

val GLOBAL_listTitleLoan = listOf(
    "Сумма выплат",
    "Процент",
    "Основная сумма кредита",
    "Комиссии",
)

val GLOBAL_listDeposit = listOf(
    "Сумма процента",
    "Основная сумма кредита",
)

val GLOBAL_listInvestments = listOf(
    "Сумма процента",
    "Основная сумма Инвестиции",
)

val GLOBAL_listTitleMortgage = listOf(
    "Ежемесячный платеж",
    "Процентные расходы по ипотеке",
    "Переплата по ипотеке",
    "Эффективная ставка",
)