package com.smarters.moneyes.game.utils

const val WIDTH_UI  = 1150f
const val HEIGHT_UI = 2493f

const val TIME_ANIM_SCREEN = 0.222f