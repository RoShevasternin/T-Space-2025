package com.smarters.moneyes.game.actors.checkbox

class ATouchCheckBoxGroup {
    var currentCheckedCheckBox: ATouchCheckBox? = null
}