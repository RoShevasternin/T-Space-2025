package com.sukapital.saepital.game.utils

const val WIDTH_UI  = 827f
const val HEIGHT_UI = 1796f

const val TIME_ANIM = 0.1f