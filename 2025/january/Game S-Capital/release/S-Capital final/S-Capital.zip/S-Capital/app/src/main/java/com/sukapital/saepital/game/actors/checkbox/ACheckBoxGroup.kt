package com.sukapital.saepital.game.actors.checkbox

class ACheckBoxGroup {
    var currentCheckedCheckBox: ACheckBox? = null
}