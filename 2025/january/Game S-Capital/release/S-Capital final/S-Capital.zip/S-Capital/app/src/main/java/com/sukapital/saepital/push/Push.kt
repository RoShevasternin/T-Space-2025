package com.sukapital.saepital.push

data class Push(
    val icon: Int,
    val title: String,
    val text: String
)
