package com.borocbernay.kasshsemir.game.utils

const val WIDTH_UI  = 865f
const val HEIGHT_UI = 1873f

const val TIME_ANIM_SCREEN = 0.0f