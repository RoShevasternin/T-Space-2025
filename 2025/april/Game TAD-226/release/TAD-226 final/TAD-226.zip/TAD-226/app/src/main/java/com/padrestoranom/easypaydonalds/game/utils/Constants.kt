package com.padrestoranom.easypaydonalds.game.utils

const val WIDTH_UI  = 833f
const val HEIGHT_UI = 1808f

const val TIME_ANIM_SCREEN = 0.345f

val GLOBAL_listCategoryName_Expense = listOf(
    "Ürünler",
    "Satın Almalar",
    "Çalışmak",
    "Spor",
    "Nakliye",
    "Ev",
    "Hediyeler",
    "Seyahat",
    "restoran",
)
val GLOBAL_listCategoryName_Income = listOf(
    "Çalışmak",
    "Spor",
    "Hediyeler",
)