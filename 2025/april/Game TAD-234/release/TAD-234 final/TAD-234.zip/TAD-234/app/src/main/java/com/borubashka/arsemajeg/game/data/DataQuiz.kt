package com.borubashka.arsemajeg.game.data

data class DataQuiz(
    val listQ : List<String>,
    val listA : List<List<String>>,
)
