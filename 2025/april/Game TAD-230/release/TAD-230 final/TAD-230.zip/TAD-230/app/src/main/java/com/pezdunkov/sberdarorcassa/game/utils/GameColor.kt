package com.pezdunkov.sberdarorcassa.game.utils

import com.badlogic.gdx.graphics.Color

object GameColor {

    val background: Color = Color.valueOf("323232")

}