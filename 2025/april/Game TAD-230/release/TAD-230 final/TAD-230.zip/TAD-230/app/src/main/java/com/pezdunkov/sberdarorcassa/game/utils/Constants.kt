package com.pezdunkov.sberdarorcassa.game.utils

const val WIDTH_UI  = 710f
const val HEIGHT_UI = 1537f

const val TIME_ANIM_SCREEN = 0.0f