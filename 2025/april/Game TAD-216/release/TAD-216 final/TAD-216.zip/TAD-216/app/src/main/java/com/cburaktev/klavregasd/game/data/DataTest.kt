package com.cburaktev.klavregasd.game.data

data class DataTest(
    val listQ : List<String>,
    val listA : List<List<String>>,
)
